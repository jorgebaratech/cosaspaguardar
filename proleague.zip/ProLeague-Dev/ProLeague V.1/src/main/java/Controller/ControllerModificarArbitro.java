package Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import Model.Arbitro;

public class ControllerModificarArbitro {
	
	
	public final static String URL = "jdbc:mysql://ligafutbol.csiagfyvzpdu.eu-west-3.rds.amazonaws.com:3306/liga_futbol";
	public final static String USER = "usuario1";
	public final static String PASSWORD = "Usuario1.";
	private static Connection con;

	static {
		try {
			con = DriverManager.getConnection(URL, USER, PASSWORD);

			System.out.println("Conexión realizada con éxito.");

		} catch (Exception e) {
			System.out.println("Error al realizar la conexión.");
			System.out.println(e);
		}
	}
	
	
	public static boolean modificarArbitro(int Licencia, String nombreNuevo, String apellidoNuevo){
		
		try {
			String sentenciaSql= "update liga_futbol.arbitro set nombre=? , apellido=? ,licecia=?";
			
			PreparedStatement st = con.prepareStatement(sentenciaSql); 
			st.setString(1, nombreNuevo);
			st.setString(2, apellidoNuevo);
			st.setInt(3, Licencia);
			
			st.executeUpdate();
			
			return true;
			
			
		} catch (Exception e) {
			System.out.println(e);
		}

		
		return false;
		
	}
	
	
	
	
	
	
	
	

}
